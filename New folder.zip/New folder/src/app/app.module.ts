import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { Injectable } from '@angular/core'; 
import { Http,Headers,RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
@ Injectable()
export class dataService {
  result:any;
  constructor(private _http:Http){}
  getUsers(){
    return this._http.get("/api/users")
  }
}


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
